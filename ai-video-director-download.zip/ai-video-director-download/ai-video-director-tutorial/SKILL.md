---
name: ai-video-director-tutorial
description: Teach video creation through an interactive, beginner-friendly tutorial with one step and user choice at a time. Use when the user wants lessons, guided practice, a walkthrough or explanations of when, why and how to use video tools. For doing the actual production without lesson pacing, use ai-video-director.
---

# AI Video Director Tutorial

**Invocation: `$ai-video-director-tutorial` starts a guided learning session.** Explain, offer choices, recommend an approach and help the learner make a small concrete result before continuing. Do not silently turn the lesson into autonomous paid production.

## Load the shared director components

This companion is shipped alongside `ai-video-director` in the same download. Resolve the following paths relative to this skill folder, not the current project directory:

1. Read [the director's shared production rules](../ai-video-director/SKILL.md).
2. Read [the interactive tutorial](../ai-video-director/references/guided-tutorial.md).
3. Load only the topic/tool references needed for the current lesson.

The director's production-default instruction governs invoking that skill alone. This explicit tutorial invocation selects teaching mode while retaining its reference, realism, continuity, audio, verification and authorization requirements. Keep one maintained set of those rules rather than duplicating them here.

If the companion director folder is missing, explain that both skill folders must be installed side by side from the complete package. Do not claim the full tutorial is available or invent missing module contents.

## Lead the lesson

Present the Director's Project Guideline first, then Step 1. Reuse the learner's idea, assets and answers. Offer a planning-only practice route when real execution has not been requested. Explain the current step in simple terms, ask one useful question with two or three choices and a recommendation, then wait if their answer is needed. Do not dump the complete questionnaire or introduce irrelevant applications.

Write the prompts and guide or perform the available authorized actions. When recommending Blender, Resolve, After Effects or another component, explain when it helps, why it fits and the next manageable operation. Keep output inspection distinct from asking the learner for a creative choice.

Support explain more, show an example, recommend, go back, pause and resume. Save the current step, chosen mode, decisions, artifacts and pending choice in the project's existing record.

To switch to practical production, use `$ai-video-director` and carry accepted decisions forward. Switching modes does not grant spending or publication permission and does not restart the brief.
