# AI Video Director

A guided video-production skill for planning Shorts, ads, drama, short films, educational videos, YouTube content and motion graphics. It asks only the questions the project needs and can prepare production handoffs when requested.

## Download

On this repository's page, select **Code -> Download ZIP**, then extract the archive. Keep the whole `ai-video-director` folder together: its references and templates are part of the skill.

## Install in Codex

1. Download and extract this repository.
2. Copy the **`ai-video-director` folder** into your personal Codex skills directory:
   - Windows: `%USERPROFILE%\.codex\skills\`
   - macOS / Linux: `~/.codex/skills/`
   - If you use a custom `CODEX_HOME`, use its `skills` directory.
3. Check that the result is `skills/ai-video-director/SKILL.md`, with `assets`, `references` and `agents` alongside it. Do not copy only `SKILL.md` or nest the folder twice.
4. Start a new Codex task and use:

```text
Use $ai-video-director to help plan my video. Start with the minimum
questions and recommend ways to save tokens and generation credits.
```

The skill is written guidance. Installing it does not install Blender, Resolve or other applications, connect accounts, or buy generation credits. It adapts to the tools actually available.

## Use the brief without installing anything

Open [video-project-brief.md](video-project-brief.md), fill the **Quick core**, and delete optional sections you do not need. Paste or attach the filled Markdown file to your preferred reasoning AI. Attach actual images/audio when the production tool requires those references.

You can write `recommend`, `skip`, `default`, `later` or `not applicable`. Missing information is flagged when it matters to the next action, rather than forcing every field at the beginning.

## What is included

- Quick, Standard and Detailed planning paths.
- Scripts, storyboards, shot lists, cinematography, design and continuity guidance.
- Character references with one primary face and separate body/costume views.
- Sound, music, readable captions, editing, graphics and delivery checks.
- Tool guidance for GPT reasoning, Higgsfield, Blender, Resolve Free, After Effects and Claude Design.
- [Savings guide](ai-video-director/references/efficiency.md): compact context, asset reuse, representative tests, low-resolution drafts, selective upscaling and bounded retries.
- Worked examples: [Short](ai-video-director/references/example-short.md), [ad](ai-video-director/references/example-ad.md), [short film](ai-video-director/references/example-film.md).

The entry point loads relevant references as needed. Optional specialist skills are discovered at handoff; this repository does not bundle third-party plugins or their source instructions.

## About cost and quality

A supported lower-resolution draft can test motion before a more expensive final. Compare the full draft, upscale and retry cost with generating at final quality directly. Upscaling cannot reliably fix wrong identity, geometry or action. The guide explains when each route is worth considering.

Model capability notes are dated observations, not promises or permanent rankings. The skill rechecks changing capabilities, costs and platform requirements when they matter. Planning does not automatically authorize spending or publication.

## Package layout

```text
README.md
video-project-brief.md
ai-video-director/
  SKILL.md
  agents/openai.yaml
  assets/
  references/
```

The included blank templates contain no account credentials or local project paths. The worked examples are fictional plans, not rendered or audience-tested videos.
