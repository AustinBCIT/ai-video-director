# DaVinci Resolve Free: editing and finishing

## Default role

Use Resolve Free as the primary candidate for assembly, sound, color, captions and suitable Fusion work. Verify installed version, operating system, available codecs and actual feature tier. "Resolve has this feature" is not sufficient evidence that Free on this machine supports it.

[Blackmagic's product page](https://www.blackmagicdesign.com/products/davinciresolve) describes the editing, Fusion, color and Fairlight workflow. Its [Studio comparison](https://www.blackmagicdesign.com/products/davinciresolve/studio), checked 2026-09-19, lists Free editing/finishing up to 60 fps and UHD 3840 x 2160. Check orientation-specific limits and the installed version for a vertical export rather than inferring support from this landscape example. Consult current codec tables for the exact format/OS; do not treat every 10-bit or hardware-accelerated workflow as included in Free.

## Before editing

Inspect source formats and test representative imports. Set timeline aspect/dimensions and exact timebase deliberately. Organize footage, audio, references and graphics; preserve originals. Use proxies/optimized media when appropriate and confirm final render uses the intended quality sources.

Build the edit around story/comprehension, then tighten rhythm, repair continuity and add graphics. Resolve/Fusion may be sufficient for titles, callouts and basic effects; recommend After Effects only for a particular unmet need or existing workflow benefit.

## Free-compatible plans

Do not make a plan depend on automatic transcription, text-based editing, Magic Mask, premium denoising or other AI/Studio features without verifying they are included in the installed Free version. Offer manual timing, supported caption-file import, ordinary masks, better source material or an allowed external process where useful. Do not silently purchase/upgrade or claim a premium operation ran.

For captions, obtain a transcript through an available authorized route, align to actual audio and verify the installed import/render options. A manual caption workflow remains valid. For advanced isolation/cleanup, state the actual limitation and offer the simplest viable alternative.

## Color/audio and handoffs

Assign source color interpretation accurately; match shots before the creative look. Avoid treating generated footage as camera log by default. Test Blender and AE handoff colors/alpha. Use Fairlight as available for dialogue/music/effects balance and measure the intended output when required.

When automation is requested, verify scripting access and operations in the installed edition. If unavailable, supply concrete manual steps or an interchange/render supported by the user's setup. Do not imply every UI action is exposed through scripting.

## Deliver

Export a short representative sample first for a new codec/alpha/color workflow. Reopen the final export and verify duration, dimensions, frame rate, channels, captions and playback. Provide a clean/captioned version only when requested. Save/export the editable Resolve project and identify external media dependencies if a source handoff is part of the brief.
