# Visual development and reference design

## Decide what each visual controls

A mood board explores feeling; a style frame establishes a finished look; a character sheet records an identity; a storyboard communicates a shot; an environment plan records space. Do not treat them as interchangeable model inputs.

For every reference, record `asset ID | role | authoritative details | allowed variation | version`. Typical roles are identity, costume, product geometry, composition, environment, lighting, style or motion. Explicitly resolve contradictory references rather than averaging them accidentally.

Start with a small number of distinct directions only when the user needs a choice. Develop the selected direction instead of repeatedly generating unrelated alternatives. State what the reference is intended to prove and inspect that property before accepting it.

## Design decisions

Select mood, tone, realism/stylization, palette, contrast, texture/materials, light quality and composition based on story and viewing context. Mood is the scene's felt atmosphere; tone is how the work treats its subject. A frightening atmosphere and a playful tone can coexist deliberately.

For branded work, capture exact colors, supplied logos, typography, spacing and mandatory copy. Use editable text/vector layers for final titles, logos and data diagrams. An AI concept image may guide layout, but its lettering is not automatically production-ready.

## Character identity and sheets

For a recurring visible character, establish an accepted identity asset before continuity-dependent production. Developing that identity can itself be an authorized first step. Gather distinguishing features, approximate age presentation, proportions, hairstyle, costume/materials, accessories and performance traits relevant to the film. Do not add gratuitous personal attributes.

This user's default sheet uses one clear main face. Use this panel structure:

| Panel | Content | Rule |
|---|---|---|
| A: identity | One neutral, frontal head-and-shoulders portrait, or a sufficiently clear frontal full-body hero | This is the sole detailed facial portrait on the combined sheet |
| B: front costume | Front-facing body/clothing view, neck down if A is a portrait | Preserve silhouette, limbs, garment details and shoes; no extra face |
| C: side costume | Side body/clothing view, neck down | Match scale and garment construction; do not invent a different face |
| D: back costume | Rear body/clothing view | Include rear head only if it usefully records hair/headwear; no competing facial portrait |
| E: details, conditional | Hands, shoes, jewelry, prop grip, fabric or rear hairstyle | Only add details needed by planned shots |

If A is a full-body frontal hero, it also supplies the front body view; do not duplicate it merely to fill a grid. Use neutral, even light, a plain background, consistent proportions and generous panel separation. Keep body-view scale consistent; label the portrait as a different scale. Avoid dramatic lens distortion, occluding poses or different outfits in the same identity board.

This layout is a user preference and a practical way to reduce competing face cues, not a universal scientific optimum. Some models require their own reference format. For a profile close-up, a separate profile identity image may be necessary; derive it from the accepted identity and inspect it. Explain this exception instead of adding multiple speculative heads to the base sheet.

Create or crop clean individual files for submission. A human-facing contact sheet is for review, not a default input to every model. If a model explicitly supports sheets/multi-view input, check its required format. A text description saying "same person" does not guarantee identity.

Character-sheet prompt pattern:

> Establish character CHAR-01 from the supplied accepted identity reference. Main panel: one frontal head-and-shoulders portrait with neutral expression and even lighting. Separate body panels: front and side neck-down costume views, and rear costume view. Match body proportions, garment construction, colors and accessories across panels. Plain background and consistent body-view scale. Reserve a margin for labels added afterward. Use the primary portrait as the sole visible facial identity.

This is a creative prompt, not proof that a model will obey it. Inspect every panel, split into separate outputs if needed, and omit unsupported reference/negative-prompt syntax. Render exact labels afterward.

## Environments

Record location, time/weather, geography, entrances/exits, major landmarks, materials, scale and lighting direction. For connected shots, create a simple top-down plan or a Blender blockout when it prevents spatial drift. Separate the stable layout reference from a mood image whose architecture may be inconsistent.

For a room: locate door, window, furniture and actors on the plan; choose the action axis before coverage. For a world: specify recurring design rules and only the locations shown. Do not require a huge world bible for one shot.

## Products, props and costume

Use real product photos, dimensions, approved labels and functional details when accuracy matters. Distinguish a concept product from an existing SKU. A beauty image is not evidence that a hinge, screen or attachment works correctly. Use controlled 3D/real footage/compositing for strict geometry and logos when generation cannot hold them.

Track asymmetric details explicitly: logo side, clasp position, handedness, pocket, scar or accessory. Mirroring an image can create a continuity error even when it looks attractive. A wardrobe change gets a new variant ID linked to the same character identity.

## Sprite sheets and 3D references

Only load this branch for sprite/animation/modeling needs. Specify dimensions, frame count/order, consistent pivot/baseline, padding, alpha and intended action. Orthographic modeling views need consistent scale and alignment; perspective concept art cannot establish exact orthographic geometry. Keep facial-expression studies separate from the base sheet unless the downstream tool specifically needs them.

## Acceptance

Check identity, proportions, symmetry/asymmetry, garment construction, prop count, materials, environment layout, intended aspect/crop and unwanted text. Record what is accepted and unresolved. Review references at the size/angle they will actually support. A tiny face in a full-body sheet may be insufficient for a later facial close-up.
