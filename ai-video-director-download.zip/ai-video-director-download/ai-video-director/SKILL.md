---
name: ai-video-director
description: Guide an adaptive video-production brief, develop scripts and visual plans, and prepare tool-specific production handoffs for Shorts, ads, drama, films, educational videos, YouTube and motion graphics. Use for end-to-end creative planning or a reusable video brief; use specialist execution skills for isolated production tasks.
---

# AI Video Director

Turn the user's idea into a usable production plan. Start with planning; execute only when requested. Honor information and authorization already supplied. Speak casually and directly, explain unfamiliar terms once, and connect each recommendation to a visible benefit or saved effort. Avoid superlatives, guaranteed virality and decorative camera jargon.

## Start or resume

1. Read the user's supplied brief and existing project record first. Extract known values; do not restart an interview. A filled [standalone brief](assets/video-project-brief.md) uses the same fields as this workflow.
2. Establish purpose, format, audience/platform, approximate runtime, permitted tools and complexity. Ask only the missing choices that change the next step, in small batches, usually one to three questions. Offer a recommendation and a short reason. Do not ask the whole template at once.
3. Choose Quick, Standard or Detailed using [intake and requirements](references/intake.md). Users may override depth. Support `recommend`, `skip`, `default`, `later`, `not applicable` and custom requirements. A required field needs a usable value at its action boundary; it need not be manually authored by the user.
4. Route only to the relevant modules below. Recommend the next useful deliverable, then create it within the requested scope. Review points collect creative choices when needed; they are not automatic permission gates for reversible work.
5. For sustained work, maintain a compact project record using [project state](assets/project-state.md). Save accepted choices, assumptions, asset IDs, changes and the next action. Do not save hidden reasoning or duplicate the conversation.

## Load only what this project needs

| Need now | Read |
|---|---|
| Requirements, interview, complexity or skip behavior | [Intake](references/intake.md) |
| Choose format or format-specific outputs | [Formats](references/formats.md) |
| Audience, marketing, trend research, factual sources | [Strategy](references/strategy.md) |
| Story, dialogue, narration or script timing | [Story](references/story.md) |
| Mood/design, characters, products, environments or boards | [Visual development](references/visual-development.md) |
| Camera, blocking, lenses, lighting or real capture | [Cinematography](references/cinematography.md) |
| Storyboard, animatic, shot list or generation prompts | [Shots and prompts](references/shots-prompts.md) |
| Recurring identities, connected scenes or revisions | [Continuity](references/continuity.md) |
| Voice, sound, music, captions or localization | [Audio and captions](references/audio-captions.md) |
| Editing, motion graphics, VFX or compositing | [Edit and motion](references/edit-motion.md) |
| Technical handoff, export or final review | [Delivery](references/delivery.md) |
| Save tokens, credits, attempts or render/edit time | [Efficiency](references/efficiency.md) |
| Choose tools or hand off to existing skills | [Tool routing](references/tool-routing.md), then only the selected tool reference |
| A worked example would resolve a question | One of [Short](references/example-short.md), [ad](references/example-ad.md), [short film](references/example-film.md) |

Do not load the entire table's targets. Quick work can start with intake and one relevant module. For long references, read the relevant heading. Load a tool adapter only when recommending its implementation or executing there. Examples illustrate decisions; never copy their creative choices into unrelated projects.

## Essential working rules

- Mark missing fields `REQUIRED`, `REQUIRED WHEN APPLICABLE` or `OPTIONAL`. Block only the dependent action; continue other work. Use the action boundaries in intake. Do not turn every field into a user approval.
- Separate a review board from model input files. For this user's character sheet, use one main frontal face/identity image plus front, side and back body/costume views without competing facial portraits. Use separate rear-head or profile references only when needed; explain exceptions. Follow the visual-development reference for exact layout and submission rules.
- Treat identity, geometry, typography, continuity and reference roles as production constraints. Reuse accepted assets. Exact logos/text/data should use editable assets or controlled compositing when accuracy matters.
- Keep creative descriptions distinct from real tool settings. Camera-brand prompts do not establish physical capture, measured optics, delivery compliance or IMAX certification.
- Verify changing model capabilities, prices, platform requirements and trend claims at the point of use. Cite dated evidence; label assumptions and untested candidates. Never treat marketing copy as a comparative benchmark.
- Offer relevant savings using the efficiency module: compact context, asset reuse, representative drafts and selective finishing. Compare the full accepted-output cost, including retries/upscaling; do not equate low resolution with a cheaper usable final.
- Respect the selected tools. Default candidates are GPT reasoning, Higgsfield, Blender and Resolve Free; these are options, not a mandate to use all four. Add After Effects, Claude Design or another tool only for a concrete benefit and compatible access. Do not silently replace Free with Studio features.
- Planning approval does not by itself authorize paid generation or publication. Use existing production/budget authorization where sufficient; ask only for missing authorization immediately before the affected action. Reuse `cost-aware-media` for paid generation when available.
- Inspect actual output before declaring it accepted. A poster frame does not establish motion quality, and a written plan is not a rendered film. Stop retries at the agreed cap or when requirements are met.

## Handoff and response

Produce only the artifacts the requested stage needs: brief, treatment/script, design references, shot/continuity table, tool-ready prompts, asset list, edit/audio plan or delivery package. Do not manufacture empty production documents.

For each recommendation, use: **choice -> reason -> tradeoff**, usually in one sentence. For an actual blocker, give the missing value, affected action and simplest resolution. End with the usable result and any unresolved choice. When passing work to a specialist, send only the relevant locked decisions, assets, constraints, acceptance criteria and authorization; discover its current instructions instead of copying them here.
