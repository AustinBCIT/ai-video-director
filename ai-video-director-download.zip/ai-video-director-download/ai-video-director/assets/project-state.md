# Video project state

Copy into the working project for sustained work. This is a compact record, not another questionnaire. Delete irrelevant sections. Record decisions and evidence, not hidden reasoning.

- Project / revision / updated:
- Purpose / format / audience / platform:
- Stage / complexity:
- Runtime / aspect / dimensions / frame rate:
- Allowed and verified tools / excluded tools:
- Budget: planning estimate / authorized cap and unit / actual or reserved / attempt cap:
- Deadline / requested deliverables:

## Accepted decisions

| Field | Value | Origin / accepted date | Depends on |
|---|---|---|---|

## References and assets

| Asset ID/version | File or media ID | Role / authoritative details | Status | Used by |
|---|---|---|---|---|

## Shots and production

| Shot ID | Source/edit duration | Start -> action -> end | Assets | Tool/settings/job ID | Status / issue |
|---|---|---|---|---|---|

## Open choices and assumptions

| Item | Proposed value / uncertainty | Required by which action | Next step |
|---|---|---|---|

## Changes affecting accepted work

- Changed decision / affected assets and shots / review needed:

## Verification and capability evidence

- Checked claim or output / evidence location / date / passed, failed or not verified:
- Costs measured versus estimated; unresolved job/charge if any:

## Resume

- Last usable result:
- Next action:
- Read next: only the relevant file/section and tool reference:
